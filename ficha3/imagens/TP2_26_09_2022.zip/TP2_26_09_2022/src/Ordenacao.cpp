#include "Ordenacao.h"

Ordenacao::Ordenacao()
{
    //ctor
}

Ordenacao::~Ordenacao()
{
    //dtor
}
