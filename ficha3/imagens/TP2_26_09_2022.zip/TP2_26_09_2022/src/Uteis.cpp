#include "Uteis.h"

Uteis::Uteis()
{
    //ctor
}

Uteis::~Uteis()
{
    //dtor
}
