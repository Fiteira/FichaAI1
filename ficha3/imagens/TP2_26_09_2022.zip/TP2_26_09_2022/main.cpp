#include <iostream>
#include <time.h>
using namespace std;

#include "Uteis.h"
#include "Ordenacao.h"

int main()
{
    cout << "Hello world!" << endl;
    srand(time(NULL));
/*     int A;
    A = Uteis::LerInteiro("Qual a IDADE ? ");
    cout << "A = " << A << endl;
    A = Uteis::LerInteiro("Qual a CC ? ");
    cout << "A = " << A << endl;
*/

    int V[10];
    int N = 5;
    Uteis::GerarAleatoriamenteVector(V, N);
    Uteis::MostrarVector(V, N);
    Ordenacao::BubbleSort(V, N, "res.csv");
    Ordenacao::InsertSort(V, N, "res.csv");

    Uteis::MostrarVector(V, N);
    return 0;
}
